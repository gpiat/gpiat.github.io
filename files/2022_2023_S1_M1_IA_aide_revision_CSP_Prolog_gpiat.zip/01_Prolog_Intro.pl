/* Created by Guilhem Piat, 2022
View the interactive notebook version of this guide here:
https://swish.swi-prolog.org/p/intro_to_pl.swinb

        ##### INTRODUCTION TO PROLOG FOR CSPs #####

Prolog is a logic programming language that is typically meant to
solve logic problems, but can also easily be used as a CSP solver.

To use Prolog, you may use the online editor/console SWISH:
https://swish.swi-prolog.org/ or you may install a prolog interpreter like
SWIPL, available in the swi-prolog package on most Linux package managers.
For Windows and MacOS, see the downloads page:
https://www.swi-prolog.org/download/stable

Many code editors will default to Pascal highlighting with the .pl
extension, so make sure you're in Prolog mode if you're editing locally.
With SWIPL, start the interpreter with `swipl filename.pl` where
`filename.pl` is the program you want to load. You can reload after
having made changes with:
?- make.

For the puroses of this example, we will consider a CSP for which we have
to fill two length-3 lists with values in [1,3], and the i-th element of
both lists must differ for all index i.
L1 = [1,1,1] ; L2 = [2,2,3] is a correct answer for instance.

In Prolog, you do not write instructions or functions.
You write clauses, of which there are two types: Facts and Rules.
These clauses define predicates, which look like functions in other
languages but are a distinct concept (i.e. `predicate(Arg1, Arg2, ...).`).
Clauses end with a period (".").
Because you do not write instructions in Prolog, you do not write
algorithms. You write constraints -- what MUST be true -- and Prolog will
find solutions that satisfy your constraints.

The interpreter has a helpful `help` predicate. `?- help(==).` for intance
will bring up the help page of the `==` operator.
*/

%           # Facts & Variable Domain Definitions #

% Facts tell the program what is true.
% We typically define the domains of our variables with facts.
% Here, we define the is_valid_value predicate. It is true when given
% 1, 2, or 3 as argument.
is_valid_value(1).
is_valid_value(2).
is_valid_value(3).

% Here, we define a predicate which checks that two lists do not contain
% any values in common at any index. It is trivially true when given
% two empty lists as arguments.
no_common_index_value_pairs([], []).


%           # Rules & Constraint Definitions #

% Rules tell the program that a predicate is true, IF some conditions
% are verified.

/* Rules have the form:
    X :- Y, Z.
where `:-` means "is true if", and is followed by a list of goals.
`,` is the "conjunction" goal separator (there are other less used
goal separators, see `help(;).` for "disjunction").
In the previous example, X is true if goals Y and Z are both true.
See `help(,).` for more information.

Prolog cannot natively use indexed collections or loops. Looping can
only be done recursively. Therefore, we define a recursive rule such
that no_common_index_value_pairs is true if:
    - The first values of the lists are different, AND
    - the rest of the lists have no common index/value pairs

[H|T] is a pattern-matching formula. H (for "Head") is a variable
containing the first value of the list. T (for "Tail") is a list
containing the rest. Variables always start with a capital.*/

no_common_index_value_pairs([H1|T1], [H2|T2]):-
    H1 =\= H2, % The numeric inequality operator is not !=, but =\=
    no_common_index_value_pairs(T1, T2).

% Eventually, T1 and T2 will match to the empty list, and
% no_common_index_value_pairs(T1, T2) will match to
% no_common_index_value_pairs([], []) which we have defined to be true.

% This predicate checks if a list contains only values in [1, 3]. This
% is trivially true when it contains nothing.
contains_only_valid_values([]).
% Recursively check that every value is valid.
contains_only_valid_values([H|T]):-
    is_valid_value(H),
    contains_only_valid_values(T).

% Users do not assign values to variables in Prolog. We define
% constraints on the possible values a variable can have and let
% the solver figure it out.
% Here, we constrain the second argument to have a length equal to
% the first. `len(const, Var)` will assign to `Var` the length of
% `const`, and `len(Var, const)` will assign a list of length
%`const` to `Var`.
len([], 0).
% The underscore ("_") is used when we don't need to name a variable.
len([_|T], Length):-
    len(T, Length2),
    % `is` is the equality operator for numeric values on the left and
    % expressions on the right (which is different from `=:=`, the
    % equality operator for Numbers on left and right).
    Length is Length2 + 1.
% (Actually the `length` predicate already does this, but we're
% reimplementing it for the example).


%     # Defining Variables, Specifying the Domains & Constraints. #

% We define a predicate which solves the problem. It takes our
% variables as arguments and will search for values for these
% variables which satisfy all of the goals.
% As our goals, we specify the domain of all variables
% and the constraints, separated by conjunctions
% (*i.e.* AND, represented with a `,`).
solve(X1, X2):-
    % Domain definition
    len(X1, 3),
    len(X2, 3),
    contains_only_valid_values(X1),
    contains_only_valid_values(X2),
    % Constraints
    no_common_index_value_pairs(X1, X2).

/*
Typically, you'll want to optimize your `solve()` predicate by introducing
constraints as soon as the domain of the relevant variables is specified
as this prunes branches of the search tree early.

                        # Running the program #

To call the `solve()` predicate locally with a `.pl` file, load the
file in your Prolog Interpreter and enter:
?- solve(X, Y).
This is called a Query. (You can use different variable names than X and Y
if you want, it doesn't matter).
Prolog will give you a value for X and a value for Y such that `solve(X, Y)`
is true. In SWIPL, ENTER will end the program, and N will generate another
solution. SWISH has clickable buttons for the same thing.
*/