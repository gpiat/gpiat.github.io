% Created by Guilhem Piat, 2022
% Load this program in a prolog interpreter like swipl or SWISH
% ( https://swish.swi-prolog.org/ ) and run the following query:
% ?- better_solve(A1, A2, A3, B1, B2, B3, C1, C2, C3)

% Defining the facts for the domains of our values.
% Only 1, 2, and 3 are possible values, and all our
% variables share the same domain.
domain(1).
domain(2).
domain(3).


% Makes sure arg1 (any) is not in arg2 (list).
% Trivially, "anything" is not in "nothing".
not_in(_, []).
% =\= is the numeric inequality operator
not_in(X, [H|T]):-
    X =\= H,
    not_in(X, T).

% Defining the rule to verify that all elements
% of a list are different.
% Trivially, there are no duplicates in a list
% of length 0 or 1.
alldiff([]).
alldiff([_]).
alldiff([H|T]):-
    not_in(H, T),
    alldiff(T).


% Defining the rule which solves the problem.
% Non-optimized version. 62k steps (13 ms) to solve.
solve(A1, A2, A3, B1, B2, B3, C1, C2, C3) :-
    % Define the domain of all variables
    domain(A1),
    domain(A2),
    domain(A3),
    domain(B1),
    domain(B2),
    domain(B3),
    domain(C1),
    domain(C2),
    domain(C3),
    % Enforce all different rows and columns
    alldiff([A1, A2, A3]), % Row A
    alldiff([B1, B2, B3]), % Row B
    alldiff([C1, C2, C3]), % Row C
    alldiff([A1, B1, C1]), % Col 1
    alldiff([A2, B2, C2]), % Col 2
    alldiff([A3, B3, C3]), % Col 3
    % Enforce additional constraints
    % =:= is the equality operator on numeric values
    A1 + A2 + B2 =:= 5,
    A3 + B3 =:= 4,
    C2 + C3 =:= 5,
    B1 + C1 =:= 4.

% Optimized version. 333 steps (<1ms) to solve.
better_solve(A1, A2, A3, B1, B2, B3, C1, C2, C3) :-
    define(A1),
    define(A2),
    define(A3),
    alldiff([A1, A2, A3]),
    define(B1),
    define(B2),
    A1 + A2 + B2 =:= 5,
    define(B3),
    alldiff([B1, B2, B3]),
    A3 + B3 =:= 4,
    define(C1),
    alldiff([A1, B1, C1]),
    B1 + C1 =:= 4,
    define(C2),
    alldiff([A2, B2, C2]),
    define(C3),
    alldiff([C1, C2, C3]),
    alldiff([A3, B3, C3]),
    C2 + C3 =:= 5.
