% Created by Guilhem Piat, 2022
% Load this program in a prolog interpreter like swipl or SWISH
% ( https://swish.swi-prolog.org/ ) and run the following query:
% ?- better_solve(X1, X2, X3, X4, X5, X6, X7, X8, X9, X10)

% For our domains, we can give all variables the same domain
% and put a constraint on the length of the variables, or we
% can have the 3-letter-word domain and the 4-letter domain.
% We do the latter as it is more efficient in Prolog.

% Defining the facts for the domains of our length-3 words 
word3('BOA').
word3('LOT').
word3('ONT').
word3('PAF').
word3('POT').
word3('POU').

% Defining the facts for the domains of our length-4 words 
word4('CLUB').
word4('FUIT').
word4('PUIS').
word4('PULL').


% Makes sure arg1 (any type) is not in arg2 (list).
% This is trivially true for the empty list.
not_in(_, []).
% \== is the non-numeric inequality operator
not_in(X, [Y|T]):-
    X \== Y,
    not_in(X, T).

% Defining the rule to verify that all elements
% of a list are different.
alldiff([_]).
alldiff([H|T]):-
    not_in(H, T),
    alldiff(T).


% Defining the rule which solves the problem.
% Intuitive, non-optimized version. This version finds
% the solution in 4.7 million steps (0.7s), and proves
% it is unique in 141.7M additional steps (21s).
solve(X1, X2, X3, X4, X5, X6, X7, X8, X9, X10) :-
    % Define the domain of all variables
    word4(X1),
    word3(X2),
    word4(X3),
    word4(X4),
    word3(X5),
    word4(X6),
    word3(X7),
    word3(X8),
    word3(X9),
    word3(X10),
    % Enforce all different
    alldiff([X1, X2, X3, X4, X5, X6, X7, X8, X9, X10]),
    
    % You can get a substring with
    % sub_string(Str, Start_index, Length,
    %            Length_remaining, SubStr).
    % see `help(sub_string).`
    % Get all shared characters
    sub_string(X1,  3, 1, _, X1_4), 
    sub_string(X2,  0, 1, _, X2_1), 
    sub_string(X2,  2, 1, _, X2_3), 
    sub_string(X3,  0, 1, _, X3_1), 
    sub_string(X3,  1, 1, _, X3_2),
    sub_string(X3,  3, 1, _, X3_4),
    sub_string(X4,  0, 1, _, X4_1),
    sub_string(X4,  3, 1, _, X4_4),
    sub_string(X5,  0, 1, _, X5_1),
    sub_string(X5,  1, 1, _, X5_2),
    sub_string(X5,  2, 1, _, X5_3),
    sub_string(X6,  0, 1, _, X6_1),
    sub_string(X7,  0, 1, _, X7_1),
    sub_string(X7,  2, 1, _, X7_3),
    sub_string(X8,  0, 1, _, X8_1),
    sub_string(X8,  1, 1, _, X8_2),
    sub_string(X8,  2, 1, _, X8_3),
    sub_string(X9,  0, 1, _, X9_1),
    sub_string(X9,  2, 1, _, X9_3),
    sub_string(X10, 2, 1, _, X10_3),

    % Check for equality of shared characters
    % == is the non-numeric equality operator
    X2_1 == X1_4,
    X5_1 == X3_1,
    X5_2 == X2_3,
    X5_3 == X4_1,
    X7_1 == X6_1,
    X7_3 == X3_2,
    X8_1 == X3_4,
    X8_3 == X4_4,
    X9_1 == X8_2,
    X9_3 == X10_3.


% Optimized version -- introduces equality constraints
% ASAP to cut off exploration of bad branches early.
% Finds the solution in 450 steps (< 1 ms), and proves
% it is unique in 370 additional steps.
better_solve(X1, X2, X3, X4, X5, X6, X7, X8, X9, X10) :-
    word4(X1),
    sub_string(X1, 3, 1, _, X1_4),

    word3(X2),
    sub_string(X2, 0, 1, _, X2_1),
    X2_1 == X1_4,
    sub_string(X2, 2, 1, _, X2_3),

    word4(X3),
    sub_string(X3, 0, 1, _, X3_1),
    sub_string(X3, 1, 1, _, X3_2),
    sub_string(X3, 3, 1, _, X3_4),

    word4(X4),
    sub_string(X4, 0, 1, _, X4_1),
    sub_string(X4, 3, 1, _, X4_4),

    word3(X5),
    sub_string(X5, 0, 1, _, X5_1),
    X5_1 == X3_1,
    sub_string(X5, 1, 1, _, X5_2),
    X5_2 == X2_3,
    sub_string(X5, 2, 1, _, X5_3),
    X5_3 == X4_1,

    word4(X6),
    sub_string(X6, 0, 1, _, X6_1),

    word3(X7),
    sub_string(X7, 0, 1, _, X7_1),
    X7_1 == X6_1,
    sub_string(X7, 2, 1, _, X7_3),
    X7_3 == X3_2,

    word3(X8),
    sub_string(X8, 0, 1, _, X8_1),
    X8_1 == X3_4,
    sub_string(X8, 1, 1, _, X8_2),
    sub_string(X8, 2, 1, _, X8_3),
    X8_3 == X4_4,

    word3(X9),
    sub_string(X9, 0, 1, _, X9_1),
    X9_1 == X8_2,
    sub_string(X9, 2, 1, _, X9_3),

    word3(X10),
    sub_string(X10, 2, 1, _, X10_3),
    X9_3 == X10_3,

    alldiff([X1, X2, X3, X4, X5, X6, X7, X8, X9, X10]).
