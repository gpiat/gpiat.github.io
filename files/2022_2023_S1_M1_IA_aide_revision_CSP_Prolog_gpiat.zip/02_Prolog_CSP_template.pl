/*  Created by Guilhem Piat, 2022
    CSP definition template 
*/

% Defining the facts for our various domains.
    % value1 -- value5 are `atoms`. You can
    % think of them as an enum if it helps.
domain1(value1).
domain1(value2).
domain1(value3).

domain2(value3).
domain2(value4).
domain2(value5).

% Defining facts and rules for our constraints
%   Classic constraints
% It is trivially true that no matter what the
% first arg is, it cannot be in the empty list
not_in(_, []).
not_in(X, [Y|T]):-
    % remember to use the proper operators for
    % your domain.
    X \== Y,   % non-numeric inequality
    % X =\= Y, % numeric inequality
    not_in(X, T).

alldiff([_]).
alldiff([H|T]):-
    not_in(H, T),
    alldiff(T).

% Defining a predicate which solves the problem.
% 582 steps to find all solutions
solve(X1, X2, X3, X4):-
    % Define the domain of all variables
    domain1(X1),
    domain1(X2),
    domain2(X3),
    domain2(X4),

    % Enforce constraints
    alldiff([X1, X2, X3]),
    X1 == X4.    % non-numeric equality
    % X1 =:= X4. % numeric equality

% Optimizing the predicate, checking constraints ASAP
% 74 steps to find all solutions
better_solve(X1, X2, X3, X4):-
    domain1(X1),
    domain2(X4),
    X1 == X4,
    domain1(X2),
    domain2(X3),
    alldiff([X1, X2, X3]).

